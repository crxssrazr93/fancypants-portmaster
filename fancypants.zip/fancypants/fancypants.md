## Installation

Buy the game on [Steam](https://store.steampowered.com/app/1668460/) and copy everything from its install folder into `ports/fancypants/gamedata/` (you should see `ClassicPack.swf` and the folders `World1` to `World4`). The first launch patches the files and converts the World 4 textures, which takes a few minutes. Only the current Steam release is supported.

## Controls

Buttons are named as the game's prompts show them. They work by position, as SDL lays them out: A is the bottom button (labelled B on Anbernic devices). On Knulli you can swap them per game: long press X on the game in the ports list and change its A/B layout setting.

| Button | Action |
|--|--|
| D-pad / Left stick | Move, Up enters doors, Down ducks |
| A / B / X / Y | Jump / Attack / Special / Special 2 |
| Start | Pause |
| L1 / L2 | Cycle quality / Mute music |
| Right stick, R1 / R2 | Mouse, click |
| Select + Start | Quit |

## Notes

* On 1 GB devices turn on zram (or swap) in your firmware's settings, so the game does not run out of memory.
* World 4 (the hub) runs at about 15 fps on an RG35XX H, but at the right game speed.
* World 3 is the heaviest world. On an RG35XX H it keeps close to full speed by drawing fewer frames when busy, so it can look choppier than Worlds 1 and 2.
* Entering a world door shows a short black screen while Ruffle restarts to free memory.
* Steam achievements and cloud saves are not available, progress is saved locally.
* Settings (quality, screen fit, frame rate) are in `ports/fancypants/fancypants.cfg`.

## Reporting problems

Please send `ports/fancypants/log.txt` and `ports/fancypants/patchlog.txt`. `log.txt` is rewritten on every start and the run before it is kept as `log.prev.txt` (the setup log likewise), so send both if the game was started again after the problem. Lines starting with `PORT:` list the device, firmware, screen, memory and swap, the state of the setup, and at the end how long the game ran and whether the system ran out of memory.

## Thanks

Brad Borne / Borne Games for the game, the [Ruffle](https://ruffle.rs) team, BinaryCounter for [Westonpack](https://github.com/binarycounter/Westonpack), and Adobe for dds2atf.

Source and build details: https://github.com/crxssrazr93/fancypants-portmaster
